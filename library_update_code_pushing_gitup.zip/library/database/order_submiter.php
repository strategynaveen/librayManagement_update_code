<?php
session_start();


print_r($_POST);
include("db_config.php");
if ($con->connect_error) {
	die('connection failed'.$con->connect_error);
}
else{
	echo "connection sucessfully";
}

if (empty($_POST)) {
	echo "all fields are empty";
	header('location:stud_order.php');
}
elseif (empty($_POST["regno"])) {
	echo "please relogin register number is not identified";
}
elseif (empty($_POST["sname"])) {
	echo "please relogin name is not identified";
}
elseif (empty($_POST["dept"])) {
	echo "please relogin department is not identified";
}
elseif (empty($_POST["gmail"])) {
	echo "please relogin emaill is not identified";
}
elseif (empty($_POST["mobile"])) {
	echo "please relogin mobile number is not identified";
}
elseif (empty($_POST["gender"])) {
	echo "please relogin gender is not identified";
}
elseif (empty($_POST["c_year"])) {
	echo "please relogin current year is not identified";
}
elseif (empty($_POST["book_ref"])) {
	echo "please relogin book reference number is not identified";
}
elseif (empty($_POST["bookname"])) {
	echo "please relogin book name is not identified";
}
elseif (empty($_POST["bookrack"])) {
	echo "please relogin book rack is not identified";
}
elseif (empty($_POST["edition"])) {
	echo "please relogin book edition is not identified";
}
elseif (empty($_POST["noofbooks"])) {
	echo "please relogin number of books is not identified";
}
elseif (empty($_POST["bookdept"])) {
	echo "please relogin book department is not identified";
}
elseif (empty($_POST["regulation"])) {
	echo "please relogin book regulation is not identified";
}
else{
	

	
	echo "all is verified";
	$regno = $_POST["regno"];
	$mobile = $_POST["mobile"];
	$gender = $_POST["gender"];
	$c_year = $_POST["c_year"];
	$sname = $_POST["sname"];
	$dept = $_POST["dept"];
	$gmail = $_POST["gmail"];
	$ref = $_POST["book_ref"];
	$bname = $_POST["bookname"];
	$brack = $_POST["bookrack"];
	$bedition = $_POST["edition"];
	$noofbooks = $_POST["noofbooks"];
	$bdept = $_POST["bookdept"];
	$regulation = $_POST["regulation"];

	$date = date('d-m-y : h:i:sa');

	$query = "SELECT * FROM `stud_order` WHERE  `regno`='$regno' AND `refno`='$ref' ";
	$res=mysqli_query($con,$query);
		$row=mysqli_fetch_array($res);
		$count=mysqli_num_rows($res);
	if ($count==1) {
		echo "<br>";
		echo "Already You Order The Book So Please Goto Login Page";
	}
	else{
		
		$stmt = $con->prepare("INSERT INTO `stud_order`(`regno`, `name`, `dept`, `email`, `mobile`, `refno`, `b_name`, `b_count`, `current_year`, `gender`, `b_dept`, `edition`, `rackno`, `regulation`,`order_date`) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");	    
        $stmt->bind_param("isssiisisssiiis",$regno,$sname,$dept,$gmail,$mobile,$ref,$bname,$noofbooks,$c_year,$gender,$bdept,$bedition,$brack,$regulation,$date);
	    $stmt->execute();
	    echo "<br>";
		echo "**********************************Record Inserted Successfully **************************************";
	
	    $stmt->close();
	    $con->close();
	}

}


session_destroy();

?>