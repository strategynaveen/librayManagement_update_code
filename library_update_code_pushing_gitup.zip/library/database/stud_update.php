<?php

//print_r($_POST);

if ((empty($_POST["regno"])) && (empty($_POST["name"])) && (empty($_POST["dept"])) && (empty($_POST["mobile"])) && (empty($_POST["gmail"])) && (empty($_POST["gender"])) && (empty($_POST["address"])) && (empty($_POST["dob"])) && (empty($_POST["current_year"]))) {
	echo "Please Enter The All Fields";
}
elseif (empty($_POST["regno"])) {
	echo "Please Enter The RegisterNumber";
}
elseif (empty($_POST["name"])) {
	echo "Please Enter The Name";
}
elseif (empty($_POST["dept"])) {
	echo "Please Enter The Department";
}
elseif (empty($_POST["mobile"])) {
	echo "Please Enter The Mobile Number";
}
elseif (empty($_POST["gmail"])) {
	echo "Please Enter The Gmail";
}
elseif (empty($_POST["gender"])) {
	echo "Please Enter The Gender";
}
elseif (empty($_POST["address"])) {
	echo "Please Enter The Address";
}
elseif (empty($_POST["dob"])) {
	echo "Please Enter The DateOfBirth";
}
elseif (empty($_POST["current_year"])) {
	echo "Please Enter The Current Year";
}
else{
	//echo "all this correct";
	include('db_config.php');
	if ($con->connect_error) {
		die('connection failed'.$con->connect_error);
	}
	else{
		echo "connection successfully";
		$regno = $_POST["regno"];
		$name = $_POST["name"];
		$dept = $_POST["dept"];
		$gmail = $_POST["gmail"];
		$mobile = $_POST["mobile"];
		$gender = $_POST["gender"];
		$address = $_POST["address"];
		$dob = $_POST["dob"];
		$current_year = $_POST["current_year"];  
		$sql = "UPDATE `student` SET `name`=?,`dept`=?,`mobile`=?,`gmail`=?,`gender`=?,`address`=?,`dob`=?,`current_year`=? WHERE `regno`=? ";
		$stmt = $con->prepare($sql);
		$stmt->bind_param("ssisssssi",$name,$dept,$mobile,$gmail,$gender,$address,$dob,$current_year,$regno);
		$stmt->execute();
		echo "<br>";
		echo "Record Updated Successfully";


	}
}

$stmt->close();
$con->close();
?>