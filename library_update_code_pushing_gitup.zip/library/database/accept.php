<?php

//print_r($_POST);

include('db_config.php');
if ($con->connect_error) {
	die('connection failed'.$con->connect_error);
}
else{
	echo "connection successfully";

	if ((empty($_POST["regno"])) && (empty($_POST["name"])) && (empty($_POST["dept"])) && (empty($_POST["gender"])) && (empty($_POST["c_year"])) && (empty($_POST["bname"])) && (empty($_POST["refno"])) && (empty($_POST["bcount"])) && (empty($_POST["del_date"])) && (empty($_POST["deuo_date"])) && (empty($_POST["sub_status"]))) {
		echo "Please Enter The Fields";
	}
	elseif (empty($_POST["regno"])) {
		echo "Please Enter The RegisterNumber";
	}
	elseif (empty($_POST["name"])) {
		echo "Please Enter The Name";
	}
	elseif (empty($_POST["dept"])) {
		echo "Please Enter The Department";
	}
	elseif (empty($_POST["gender"])) {
		echo "Please Enter The Gender";
	}
	elseif (empty($_POST["c_year"])) {
		echo "Please Enter The CurrentYear";
	}
	elseif (empty($_POST["bname"])) {
		echo "Please Enter The BookName";
	}
	elseif (empty($_POST["refno"])) {
		echo "Please Enter The ReferenceNumber";
	}
	elseif (empty($_POST["bcount"])) {
		echo "Please Enter The BookCounting";
	}
	elseif (empty($_POST["del_date"])) {
		echo "Please Enter The Delivery Date";
	}
	elseif (empty($_POST["deuo_date"])) {
		echo "Please Enter The Deuo Date";
	}
	elseif (empty($_POST["sub_status"])) {
		echo "Please Enter The Submission Status";
	}
	else{
		//echo "all is correct";
		$del_date=$_POST["del_date"];
		$deuo_date=$_POST["deuo_date"];
		$refno=$_POST["refno"];
		$regno=$_POST["regno"];
		/*$dept=$_POST["dept"];
		$gender=$_POST["gender"];
		$c_year=$_POST["c_year"];
		$bname=$_POST["bname"];
		$bcount=$_POST["bcount"];*/
		$sub_status=$_POST["sub_status"];


		$sql ="UPDATE `stud_order` SET `del_date`='$del_date' , `deuo_date`='$deuo_date' ,`sub_status`='$sub_status' WHERE `regno`='$regno' AND `refno`='$refno' ";
		$res = $con->query($sql);
		if ($res==true) {
			echo "Query Updated";
		}
		else{
			echo "Query Failed";
		}
	}
}

?>