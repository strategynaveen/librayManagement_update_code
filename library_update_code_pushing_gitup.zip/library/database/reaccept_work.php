<?php

print_r($_POST);

include('db_config.php');
if ($con->connect_error) {
	die('connection failed'.$con->connect_error);
}
else{
	echo "connection successfully";
	echo "<br>";
	$regno = $_POST["reg"];
	$refno = $_POST["ref"];

	if ((empty($regno)) && (empty($refno))) {
		header('location: lib_work.php');
	}
	elseif (empty($regno)) {
		header('location: lib_work.php');
	}
	elseif (empty($refno)) {
		header('location: lib_work.php');
	}
	else{
		//echo "all is correct";

		$sql = "SELECT * FROM `book_reg` WHERE `book_ref`='$refno' ";
		$res=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($res);
		$count=mysqli_num_rows($res);
		if ($count==1) {
			echo "login success";
			echo "<br>";
			$book_count=$row["noofbooks"];
			$b_count=$book_count-1;
			$sql1 = "UPDATE `stud_order` SET `b_count`='$b_count' WHERE `refno`='$refno' AND `status` IS NULL";
			$out = $con->query($sql1);
			if ($out==true) {
					echo "updated in stud_order in status is null";
					echo "<br>";
					$sql2 = "UPDATE `book_reg` SET `noofbooks`='$b_count' WHERE `book_ref`='$refno'";
					$output = $con->query($sql2);
					if ($output==true) {
						echo "book registeration table is updated";
						echo "<br>";
						$sql3 = "UPDATE `stud_order` SET `b_count`=1, `status`='accepted',`reason`= NULL WHERE `regno`='$regno' AND `refno`='$refno'";
							$out1 = $con->query($sql3);
							if ($out1 == true) {
								echo "Accepted";

							}
							else{
								echo "<br>";
								echo "not accepted";
							}
					}else{
						echo "book registration table not updated";
					}
			}	
			else{
					echo "not update stud_order book status is null";
			}
		}
		else{
			echo "login failed in book registeration table";
		}
	}
}


?>