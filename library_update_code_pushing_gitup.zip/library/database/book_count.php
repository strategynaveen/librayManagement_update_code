<?php

include('db_config.php');
if ($con->connect_error) {
	die('connection failed'.$con->connect_error);
}
else{
	//echo "connection successfully";

	$sql=mysqli_query($con,"SELECT * FROM `book_reg` WHERE bookdept = 'cse'");
	$count=mysqli_num_rows($sql);

	$sql1=mysqli_query($con,"SELECT * FROM `book_reg` WHERE bookdept = 'mech'");
	$count1=mysqli_num_rows($sql1);

	$sql2=mysqli_query($con,"SELECT * FROM `book_reg` WHERE bookdept = 'civil'");
	$count2=mysqli_num_rows($sql2);

	$sql3=mysqli_query($con,"SELECT * FROM `book_reg` WHERE bookdept = 'eee'");
	$count3=mysqli_num_rows($sql3);

	$sql4=mysqli_query($con,"SELECT * FROM `book_reg` WHERE bookdept = 'ece'");
	$count4=mysqli_num_rows($sql4);


}


?>
<div class="table-responsive table-sm">
	<table class="table-hover table">
		<thead class="bg-dark text-white">
			<tr>
				<th>S.NO</th>
				<th>BOOKDEPT</th>
				<th>COUNTING</th>
				<th>Selection</th>
			</tr>
		</thead>
		<tbody>
			<tr>
				<td>1</td>
				<td>CSE</td>
				<td><?php echo $count; ?></td>
				<td><button class="btn btn-md btn-primary" onclick="func()">ClickHere</button></td>
			</tr>
			<tr>
				<td>2</td>
				<td>MECH</td>
				<td><?php echo $count1; ?></td>
				<td><button class="btn btn-md btn-primary" onclick="mech()">ClickHere</button></td>
			</tr>
			<tr>
				<td>3</td>
				<td>Civil</td>
				<td><?php echo $count2; ?></td>
				<td><button class="btn btn-md btn-primary" onclick="civil()">ClickHere</button></td>
			</tr>
			<tr>
				<td>4</td>
				<td>EEE</td>
				<td><?php echo $count3; ?></td>
				<td><button class="btn btn-md btn-primary" onclick="eee()">ClickHere</button></td>
			</tr>
			<tr>
				<td>5</td>
				<td>ECE</td>
				<td><?php echo $count4; ?></td>
				<td><button class="btn btn-md btn-primary" onclick="ece()">ClickHere</button></td>
			</tr>

		</tbody>
	</table>
</div>