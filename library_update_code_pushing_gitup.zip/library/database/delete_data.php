<?php

if (empty($_POST)) {
	header("location: lib_work.php");
}
elseif (empty($_POST["regno"])) {
	header('location: lib_work.php');
}
elseif (empty($_POST["refno"])) {
	header('location: lib_work.php');
}
else{
	//echo "ok";
	$regno=$_POST["regno"];
	$refno=$_POST["refno"];

	include('db_config.php');
	if ($con->connect_error) {
		die('connection failed'.$con->connect_error);
	}
	else{
		//echo "connection successfully";

		$sql = "DELETE FROM `stud_order` WHERE `regno`='$regno' AND `refno`='$refno'";
		$res = $con->query($sql);
		if ($res == true) {
			echo "Deleted SuccessFully";
		}
		else{
			echo "Error Something";
		}
	}
	

}

?>