<?php
include('db_config.php');
if ($con->connect_error) {
	die('connecction failed '.$con->connect_error);
}
else{
	$regno = $_GET["regno"];
	echo "connection successfully";
	$sql = "SELECT * FROM `stud_order` WHERE `regno` ='$regno' AND `status` IS NULL";
	$res = $con->query($sql);
	if ($res==true) {
		//echo "query true";
		if ($res->num_rows>0) {
			while ($row = $res->fetch_assoc()) {
										
				echo "<div class='col-lg-6 col-md-6 col-sm-12 col-12'>";
				echo "<div class='jumbotron'>";
				echo "<div class='row'>";
				echo "<div class='col-6'>";
				echo "<h6 class='font-weight-bold'>BooKName</h6>";
				echo "</div>";
				echo "<div class='col-6'>";
				echo "<h6 class=' text-info font-weight-bold'>{$row['b_name']}</h6>";
				echo "</div>";
				echo "</div>";
				echo "<div class='row'>";
				echo "<div class='col-6'>";
				echo "<h6 class='font-weight-bold'>Count</h6>";
				echo "</div>";
				echo "<div class='col-6'>";
				echo "<h6 class=' text-info font-weight-bold'>{$row['b_count']}</h6>";
				echo "</div>";
				echo "</div>";
				echo "<div class='row'>";
				echo "<div class='col-6'>";
				echo "<h6 class='font-weight-bold'>Regulation</h6>";
				echo "</div>";
				echo "<div class='col-6'>";
				echo "<h6 class=' text-info font-weight-bold'>{$row['regulation']}</h6>";
				echo "</div>";
				echo "</div>";
				echo "<div class='row'>";
				echo "<div class='col-6'>";
				echo "<h6 class='font-weight-bold'>b_dept</h6>";
				echo "</div>";
				echo "<div class='col-6'>";
				echo "<h6 class=' text-info font-weight-bold'>{$row['b_dept']}</h6>";
				echo "</div>";
				echo "</div>";
				echo "<div class='row'>";
				echo "<div class='col-6'>";
				echo "<h6 class='font-weight-bold'>Edition</h6>";
				echo "</div>";
				echo "<div class='col-6'>";
				echo "<h6 class=' text-info font-weight-bold'>{$row['edition']}</h6>";
				echo "</div>";
				echo "</div>";
				echo "<div class='row'>";
				echo "<div class='col-6'>";
				echo "<h6 class='font-weight-bold'>RackNo</h6>";
				echo "</div>";
				echo "<div class='col-6'>";
				echo "<h6 class=' text-info font-weight-bold'>{$row['rackno']}</h6>";
				echo "</div>";
				echo "</div>";
				echo "<div class='row'>";
				echo "<div class='col-6'>";
				echo "<h6 class='font-weight-bold'>Regno</h6>";
				echo "</div>";
				echo "<div class='col-6'>";
				echo "<h6 class=' text-info font-weight-bold'>{$row['regno']}</h6>";
				echo "</div>";
				echo "</div>";
				echo "<div class='row'>";
				echo "<div class='col-6'>";
				echo "<h6 class='font-weight-bold'>Name</h6>";
				echo "</div>";
				echo "<div class='col-6'>";
				echo "<h6 class=' text-info font-weight-bold'>{$row['name']}</h6>";
				echo "</div>";
				echo "</div>";
				echo "<div class='row'>";
				echo "<div class='col-6'>";
				echo "<button type='button' class='btn btn-md btn-danger reject' data-id='{$row['refno']}'>Reject</button>";
				echo "</div>";
				echo "<div class='col-6'>";
				echo "<button type='button' class='btn btn-md btn-info accept' data_id='{$row['refno']}'>Accept</button>";
				echo "</div>";
				echo "</div>";
				echo "</div>";
				echo "</div>";
												
			}
		}
	}
}

											


?>