<?php
session_start();

//print_r($_POST);
include('db_config.php');
if ($con->connect_error) {
	die('connection failed'.$con->connect_error);
}
else{
	echo "connection successfully";
	echo "<br>";
	if ((empty($_POST["lib_uid"])) && (empty($_POST["lib_pass"]))) {
		echo "Please Fill The Entire Fields";
	}
	elseif (empty($_POST["lib_uid"])) {
		echo "Please Enter The UserId";
	}
	elseif (empty($_POST["lib_pass"])) {
		echo "Please Enter The password";
	}
	else{
		$uid=$_POST["lib_uid"];
		$pass=$_POST["lib_pass"];

		$sql="SELECT * FROM `lib_incharge` WHERE  `userid`='".$uid."' And `password`='".$pass."' ";
		$res=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($res);
		$count=mysqli_num_rows($res);
		if ($count==1) {
			echo "Login SuccessFully";
			$_SESSION["userid"] = $uid;
			//$url="C:/wamp/www/library/index.html";
			header('location: order_view.php');
		}
		else{
			echo "Login Failed";
		}
	}
}

?>