<?php

	print_r($_POST);



?>
<!DOCTYPE html>
<html>
<head>
	<title>
		strategy
	</title>
	<!-- Font Awesome --
  	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
  	<-- Google Fonts Roboto --
  	<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
  	<-- Bootstrap core CSS -->
  	<link rel="stylesheet" href="css/bootstrap.min.css">
  	<!-- Material Design Bootstrap -->
  	<link rel="stylesheet" href="css/mdb.min.css">
  	<!-- Your custom styles (optional) -->
  	<link rel="stylesheet" href="css/style.css">
  	<link rel="stylesheet" href="fa/css/font-awesome.min.css">
  	<link rel="stylesheet" type="text/css" href="style.css">
  	<!--<link rel="stylesheet" type="text/css" href="main.css">----->
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-lg-3"></div>
			<div class="col-lg-6">
				<div class="jumbotron">
					<h1>hi naveen</h1>
				</div>
			</div>
			<div class="col-lg-3"></div>
		</div>
		<div class="row">
			<div class="col-lg-3"></div>
			<div class="col-lg-6">
			<div class="jumbotron">
				<div class="row">
				<div class="col-lg-4">
					<input type="submit" class="btn bt-lg btn-info" name="">
				</div>
				<div class="col-lg-4">
					<input type="submit" class="btn bt-lg btn-info" name="">
				</div>
				<div class="col-lg-4">
					<input type="submit" class="btn bt-lg btn-info" name="">
				</div>
			</div>
			</div>
		</div>
		<div class="col-lg-3"></div>
			
		</div>
	</div>

<!-- jQuery -->
  	<script type="text/javascript" src="js/jquery.min.js"></script>
  	<!-- Bootstrap tooltips -->
  	<script type="text/javascript" src="js/popper.min.js"></script>
  	<!-- Bootstrap core JavaScript -->
  	<script type="text/javascript" src="js/bootstrap.min.js"></script>
  	<!-- MDB core JavaScript -->
  	<script type="text/javascript" src="js/mdb.min.js"></script>
  	<!-- Your custom scripts (optional) -->
  	<script type="text/javascript"></script>
</body>
</html>