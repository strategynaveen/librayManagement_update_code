<?php


session_start();

$regno=$_SESSION["regno"];
$pass=$_SESSION["password"];

/**
 * 
 */
class profile
{
	public $name;
	public $pass;

	function __construct($name,$pass)
	{
		$this->name=$name;
		$this->pass=$pass;

	}
	function getsession(){
		if (empty($this->name)&&empty($this->pass)) {
			echo "<script>alert('hello guys please login ');</script>";
			header('location: ../stud_login.html');
		}
		else{
			//echo "regno is:".$this->name;
			//echo "session ok";
		}
	}
}

$obj = new profile($regno,$pass);
echo $obj->getsession();

include('db_config.php');
if ($con->connect_error) {
	die('connection failed'.$con->connect_error);
}
else{
	//echo "connection successfully";


	$sql=mysqli_query($con,"SELECT * FROM `book_reg` WHERE bookdept = 'cse'");
	$count=mysqli_num_rows($sql);

	$sql1=mysqli_query($con,"SELECT * FROM `book_reg` WHERE bookdept = 'mech'");
	$count1=mysqli_num_rows($sql1);

	$sql2=mysqli_query($con,"SELECT * FROM `book_reg` WHERE bookdept = 'civil'");
	$count2=mysqli_num_rows($sql2);

	$sql3=mysqli_query($con,"SELECT * FROM `book_reg` WHERE bookdept = 'eee'");
	$count3=mysqli_num_rows($sql3);

	$sql4=mysqli_query($con,"SELECT * FROM `book_reg` WHERE bookdept = 'ece'");
	$count4=mysqli_num_rows($sql4);


}

/**
 * 
 */

	
	
?>
<!DOCTYPE html>
<html>
<head>
	<title>BookSelect</title>
	<link rel="stylesheet" type="text/css" href="../css/bootstrap.min.css">
	<link rel="stylesheet" href="../css/mdb.min.css">
  	<!-- Your custom styles (optional) -->
  	<link rel="stylesheet" href="../css/style.css">
  	<link rel="stylesheet" href="../fa/css/font-awesome.min.css">
  	<!--<link rel="stylesheet" type="text/css" href="main.css">-->
  	<link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
	<!--navigation----->
	<div class="cont-col-nav animated bounceInRight slow">
		<h4 class="text-center ">Library Management</h4>
	</div>
	<!--Navbar -->
	<nav class=" mb-0 navbar sticky-top navbar-expand-lg navbar-dark col-nav animated bounceInRight slow" id="myHeader">
  		<a class="navbar-brand" href="#">Navbar</a>
  		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-333" aria-controls="navbarSupportedContent-333" aria-expanded="false" aria-label="Toggle navigation">
    		<span class="navbar-toggler-icon"></span>
  		</button>
  		<div class="collapse navbar-collapse" id="navbarSupportedContent-333">
    		<ul class="navbar-nav mr-auto">
      			<li class="nav-item active">
        			<a class="nav-link" href="../index.html">Home
          				<span class="sr-only">(current)</span>
        			</a>
      			</li>
      			<li class="nav-item">
        			<a class="nav-link" href="../stud_login.html">Student</a>
      			</li>
      			<li class="nav-item">
        			<a class="nav-link" href="../lib_incharge.html">Incharge</a>
      			</li>
      			<li class="nav-item dropdown">
        			<a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-333" data-toggle="dropdown"
          			aria-haspopup="true" aria-expanded="false">HOD</a>
        			<div class="dropdown-menu dropdown-default" aria-labelledby="navbarDropdownMenuLink-333">
          				<a class="dropdown-item" href="../hod_register.html">Register</a>
          				<a class="dropdown-item" href="../hod_login.html">Login</a>
          				<a class="dropdown-item" href="hod_unsubmit.php">Unsubmit</a>
        			</div>
      			</li>
    		</ul>
    		<ul class="navbar-nav ml-auto nav-flex-icons">
      			<li class="nav-item">
        			<a class="nav-link waves-effect waves-light">
          				<i class="fa fa-twitter"></i>
        			</a>
      			</li>
      			<li class="nav-item">
        			<a class="nav-link waves-effect waves-light">
          				<i class="fa fa-google-plus"></i>
        			</a>
      			</li>
      			<li class="nav-item dropdown">
        			<a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-333" data-toggle="dropdown"
          			aria-haspopup="true" aria-expanded="false">
          				<i class="fa fa-user "></i>
        			</a>
        			<div class="dropdown-menu dropdown-menu-right dropdown-default" aria-labelledby="navbarDropdownMenuLink-333">
          				<a class="dropdown-item" href="#">Action</a>
          				<a class="dropdown-item" href="#">Another action</a>
          				<a class="dropdown-item" href="#">Something else here</a>
        			</div>
      			</li>
    		</ul>
 		</div>
	</nav>
	<br>
	<!--navigation end--->
	<!------div container---->
	<div class="container">
		<div class="row">
			<div class="col-lg-6">
				<div class="jumbotron rounded shadow-lg">
					<h2 class="text-center text-info shadow-md font-weight-bold">Student Profile</h2>
					<br>
					<!--<div class="row">
						<div class="col-4"></div>
						<div class="col-4">
							<img src="../uploads/" height="150" width="150">
						</div>
						<div class="col-4"></div>
						<br>
						<div class="table-responsive table-sm">
							<table class="table-hover shadow-lg">
								<tbody>
									<tr>
										<td><h4>Regno</h4></td>
										<td><?php echo $data["regno"]; ?></td>
									</tr>
								</tbody>
							</table>
						</div>
					</div>-->
					<?php

						$query="SELECT * FROM `student` WHERE `regno`='$regno' ";
						$res=$con->query($query);
						if ($res==true) {
							//echo "query true";
							if ($res->num_rows>0) {
								while ($row=$res->fetch_assoc()) {
									echo "<div class='row'>";
									echo "<div class='col-4'></div>";
									echo "<div class='col-4'>";
									echo "<img src='../uploads/".$row["image"]." '  height='150' width='150'>";
									echo "</div>";
									echo "<div class='col-4'></div>";
									echo "</div>";
									echo "<br>";
									echo "<div class='table-responsive table-sm'>";
									echo "<table class='table-hover table'>";
									echo "<tr>";
									echo "<td></td>";
									echo "<td></td>";
									echo "<td class='font-weight-bold'>Regno</td>";
									echo "<td>:</td>";
									echo "<td>{$row['regno']}</td>";
									echo "</tr>";
									echo "<tr>";
									echo "<td></td>";
									echo "<td></td>";
									echo "<td class='font-weight-bold'>Name</td>";
									echo "<td>:</td>";
									echo "<td>{$row['name']}</td>";
									echo "</tr>";
									echo "<tr>";
									echo "<td></td>";
									echo "<td></td>";
									echo "<td class='font-weight-bold'>Department</td>";
									echo "<td>:</td>";
									echo "<td>{$row['dept']}</td>";
									echo "</tr>";
									echo "<tr>";
									echo "<td></td>";
									echo "<td></td>";
									echo "<td class='font-weight-bold'>MobileNo</td>";
									echo "<td>:</td>";
									echo "<td>{$row['mobile']}</td>";
									echo "</tr>";
									echo "<tr>";
									echo "<td></td>";
									echo "<td></td>";
									echo "<td class='font-weight-bold'>Gmail</td>";
									echo "<td>:</td>";
									echo "<td>{$row['gmail']}</td>";
									echo "</tr>";
									echo "<tr>";
									echo "<td></td>";
									echo "<td></td>";
									echo "<td class='font-weight-bold'>Gender</td>";
									echo "<td>:</td>";
									echo "<td>{$row['gender']}</td>";
									echo "</tr>";
									echo "<tr>";
									echo "<td></td>";
									echo "<td></td>";
									echo "<td class='font-weight-bold'>Address</td>";
									echo "<td>:</td>";
									echo "<td>{$row['address']}</td>";
									echo "</tr>";
									echo "<tr>";
									echo "<td></td>";
									echo "<td></td>";
									echo "<td class='font-weight-bold'>DOB</td>";
									echo "<td>:</td>";
									echo "<td>{$row['dob']}</td>";
									echo "</tr>";
									echo "<tr>";
									echo "<td></td>";
									echo "<td></td>";
									echo "<td class='font-weight-bold'>Current Year</td>";
									echo "<td>:</td>";
									echo "<td>{$row['current_year']}</td>";
									echo "</tr>";
									echo "</table>";
									echo "</div>";
									echo "<div class='row'> ";
									echo "<div class='col-6'><button type='button' class='btn btn-lg btn-info' onclick='edit()'>Edit</button></div>";
									echo "<div class='col-6'><button type='button' class='btn btn-lg btn-info ' onclick='status()'>BookStatus</button></div>";
									echo "</div>";
								}
							}
						}
						else{
							echo "Error the query"; 
							header('location: ../stud_login.html');
						}


					?>
				</div>
			</div>
			<div class="col-lg-6">
				<div class="jumbotron rounded shadow-lg">
					<h3 class="text-center text-info shadow-md font-weight-bold">BookSelection</h3>
					<br>
					<!--<div id="table_view"></div>-->
					<div class="table-responsive table-sm">
						<table class="table-hover table">
							<thead class="bg-info text-white">
								<tr>
									<th>S.NO</th>
									<th>BOOKDEPT</th>
									<th>COUNTING</th>
									<th>Selection</th>
								</tr>
							</thead>
							<tbody>
								<tr>
									<td>1</td>
									<td>CSE</td>
									<td><?php echo $count; ?></td>
									<td><button class="btn btn-md btn-primary" onclick="func()">ClickHere</button></td>
								</tr>
								<tr>
									<td>2</td>
									<td>MECH</td>
									<td><?php echo $count1; ?></td>
									<td><button class="btn btn-md btn-primary" onclick="mech()">ClickHere</button></td>
								</tr>
								<tr>
									<td>3</td>
									<td>Civil</td>
									<td><?php echo $count2; ?></td>
									<td><button class="btn btn-md btn-primary" onclick="civil()">ClickHere</button></td>
								</tr>
								<tr>
									<td>4</td>
									<td>EEE</td>
									<td><?php echo $count3; ?></td>
									<td><button class="btn btn-md btn-primary" onclick="eee()">ClickHere</button></td>
								</tr>
								<tr>
									<td>5</td>
									<td>ECE</td>
									<td><?php echo $count4; ?></td>
									<td><button class="btn btn-md btn-primary" onclick="ece()">ClickHere</button></td>
								</tr>

							</tbody>
						</table>
					</div>
				</div>
			</div>
			<!--<div class="col-lg-3"></div>-->
		</div>
	</div>


	<!----container end----->

	<!---footer------>
	<footer class="page-footer font-small blue-grey lighten-5 animated delay-2s bounceInUp">
		<div style="background-color: #21d192;">
    		<div class="container">
      			<div class="row py-4 d-flex align-items-center">
        			<div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
          				<h6 class="mb-1 font-weight-bold">Get connected with us on social networks!</h6>
        			</div>
        			<div class="col-md-6 col-lg-7 text-center text-md-right">
          				<a class="fb-ic">
            				<i class="fa fa-facebook-f fa-2x white-text mr-4"> </i>
          				</a>
          				<a class="tw-ic">
            				<i class="fa fa-twitter fa-2x white-text mr-4"> </i>
          				</a>
          			    <a class="gplus-ic">
            				<i class="fa fa-google-plus fa-2x white-text mr-4"> </i>
          				</a>
          			    <a class="li-ic">
            				<i class="fa fa-linkedin fa-2x white-text mr-4"> </i>
          				</a>
          				<a class="ins-ic">
            				<i class="fa fa-instagram fa-2x white-text"> </i>
          				</a>
        			</div>
        		</div>
      		</div>
  		</div>
  		<div class="container text-center text-md-left mt-5">
    	   	<div class="row mt-3 dark-grey-text">
      	    	<div class="col-md-3 col-lg-4 col-xl-3 mb-4">
               		<h6 class="text-uppercase font-weight-bold">Company name</h6>
        			<hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        			<p>Here you can use rows and columns to organize your footer content. Lorem ipsum dolor sit amet,
          				consectetur
          				adipisicing elit.</p>
      			</div>
      			<div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
        	    	<h6 class="text-uppercase font-weight-bold">Products</h6>
        			<hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        			<p>
          				<a class="dark-grey-text" href="#!">MDBootstrap</a>
        			</p>
        			<p>
          				<a class="dark-grey-text" href="#!">PHP,JQUERY</a>
        			</p>
        			<p>
          				<a class="dark-grey-text" href="#!">AJAX,JAVASCRIPT</a>
        			</p>
        			<p>
          				<a class="dark-grey-text" href="#!">HTML,CSS</a>
        			</p>
      			</div>
      		  	<div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
        	    	<h6 class="text-uppercase font-weight-bold">Useful links</h6>
        			<hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        			<p>
          				<a class="dark-grey-text" href="#!">Student Login</a>
        			</p>
        			<p>
          				<a class="dark-grey-text" href="#!">LibraryAdmin</a>
        			</p>
        			<p>
          				<a class="dark-grey-text" href="#!">Head Of Department</a>
        			</p>
        			<p>
          				<a class="dark-grey-text" href="#!">Representative Login</a>
        			</p>
      			</div>
      		   	<div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
        	    	<h6 class="text-uppercase font-weight-bold">Contact</h6>
        			<hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        			<p>
          				<i class="fa fa-home mr-3"></i> 79/a mettu street,  Thirupparankundream,  Madurai,  India
          			</p>
        			<p>
          				<i class="fa fa-envelope mr-3"></i> naveenkumar709434@gmail.com
          			</p>
        			<p>
          				<i class="fa fa-phone mr-3"></i> + 63 796 179 16
          			</p>
        			<p>
          				<i class="fa fa-print mr-3"></i> + 99 42 93 32 62
          			</p>
      			</div>
      		</div>
    	</div>
  	 	<div class="footer-copyright text-center text-black-50 py-3">© 2020 Copyright:
    		<a class="dark-grey-text" href="https://mdbootstrap.com/">StrategySoftwares.com</a>
  		</div>
  	</footer>
	<!---footer end---->

<!-- jQuery -->
  	<script type="text/javascript" src="../js/jquery.min.js"></script>
  	<!-- Bootstrap tooltips -->
  	<script type="text/javascript" src="../js/popper.min.js"></script>
  	<!-- Bootstrap core JavaScript -->
  	<script type="text/javascript" src="../js/bootstrap.min.js"></script>
  	<!-- MDB core JavaScript -->
  	<script type="text/javascript" src="../js/mdb.min.js"></script>
  	<script type="text/javascript">
  		$(document).ready(function(){
  			$('#table_view').load("database/stud_bookdept.php");
  		});
  		
  		function status(){
  			var regno = "<?php echo $regno; ?>";
  			alert(regno);
  			window.location.href="book_status.php?regno="+regno;
  		}
  		function func(){
  				alert("cse");
  				var dept="cse";
  				window.location.href="stud_card.php?dept="+dept;
  			}
  			 function civil(){
  				alert("civil");
  				var dept="civil";
  				window.location.href="stud_card.php?dept="+dept;
  			}

  			function mech(){
  				alert("mech");
  				var dept="mech";
  				window.location.href="stud_card.php?dept="+dept;
  			}
  			function eee(){
  				alert('eee');
  				var dept="eee";
  				window.location.href="stud_card.php?dept="+dept;
  			}
  			function ece(){
  				alert('ece');
  				var dept="ece";
  				window.location.href="stud_card.php?dept="+dept;
  			}
  			function edit(){
  				alert('edit profile');
  				var regno = "<?php echo $regno; ?>";
  				window.location.href="profile_edit.php?regno="+regno;
  			}
  	</script>
</body>
</html>
<!---<?php
	//session_destroy();


?>--->