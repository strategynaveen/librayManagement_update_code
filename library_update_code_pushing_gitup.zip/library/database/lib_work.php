<?php

include('db_config.php');
if ($con->connect_error) {
	die('connection  failed'.$con->connect_error);
}
else{
	//echo "connection successfully";

}

?>

<!DOCTYPE html>
<html>
<head>
	<title>StrategyNaveen</title>
	<!-- MDB icon -->
  <link rel="icon" href="../img/mdb-favicon.ico" type="image/x-icon">
  <!-- Font Awesome --
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
  <-- Google Fonts Roboto --
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
  <-- Bootstrap core CSS -->
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <!-- Material Design Bootstrap -->
  <link rel="stylesheet" href="../css/mdb.min.css">
  <!-- Your custom styles (optional) -->
  <link rel="stylesheet" href="../css/style.css">
  <link rel="stylesheet" href="../fa/css/font-awesome.min.css">
 <!---<link rel="stylesheet" type="text/css" href="main.css">---->
 <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
	<!----navigation----->
	<!--navigation----->
	<div class="cont-col-nav animated bounceInRight slow">
		<h4 class="text-center ">Library Management</h4>
	</div>
	<!--Navbar -->
	<nav class=" mb-0 navbar sticky-top navbar-expand-lg navbar-dark col-nav animated bounceInRight slow" id="myHeader">
  		<a class="navbar-brand" href="#">Navbar</a>
  		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-333" aria-controls="navbarSupportedContent-333" aria-expanded="false" aria-label="Toggle navigation">
    		<span class="navbar-toggler-icon"></span>
  		</button>
  		<div class="collapse navbar-collapse" id="navbarSupportedContent-333">
    		<ul class="navbar-nav mr-auto">
      			<li class="nav-item active">
        			<a class="nav-link" href="../index.html">Home
          				<span class="sr-only">(current)</span>
        			</a>
      			</li>
      			<li class="nav-item">
        			<a class="nav-link" href="../stud_login.html">Student</a>
      			</li>
      			<li class="nav-item dropdown">
        			<a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-444" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Incharge</a>
              		<div class="dropdown-menu dropdown-default" aria-labelledby="navbarDropdownMenuLink-444">
                		<a class="dropdown-item" href="../lib_incharge.html">Login</a>
                		<a class="dropdown-item" href="../book_view.html">SearchBook</a>
                		<a class="dropdown-item" href="../b_reg.html">ADDBook</a>
                		<a class="dropdown-item" href="lib_work.php">Work</a>
                		<a class="dropdown-item" href="order_view.php">Orders</a>
              		</div>
      			</li>
      			<li class="nav-item dropdown">
        			<a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-333" data-toggle="dropdown"
          			aria-haspopup="true" aria-expanded="false">HOD</a>
        			<div class="dropdown-menu dropdown-default" aria-labelledby="navbarDropdownMenuLink-333">
          				<a class="dropdown-item" href="../hod_register.html">Register</a>
          				<a class="dropdown-item" href="../hod_login.html">Login</a>
          				<a class="dropdown-item" href="hod_unsubmit.php">Unsubmit</a>
        			</div>
      			</li>
    		</ul>
    		<ul class="navbar-nav ml-auto nav-flex-icons">
      			<li class="nav-item">
        			<a class="nav-link waves-effect waves-light">
          				<i class="fa fa-twitter"></i>
        			</a>
      			</li>
      			<li class="nav-item">
        			<a class="nav-link waves-effect waves-light">
          				<i class="fa fa-google-plus"></i>
        			</a>
      			</li>
      			<li class="nav-item dropdown">
        			<a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-333" data-toggle="dropdown"
          			aria-haspopup="true" aria-expanded="false">
          				<i class="fa fa-user "></i>
        			</a>
        			<div class="dropdown-menu dropdown-menu-right dropdown-default" aria-labelledby="navbarDropdownMenuLink-333">
          				<a class="dropdown-item" href="#">Action</a>
          				<a class="dropdown-item" href="#">Another action</a>
          				<a class="dropdown-item" href="#">Something else here</a>
        			</div>
      			</li>
    		</ul>
 		</div>
	</nav>
	<br>
	<!-----navigation end ------->
	<!-------container-------->
	<div class="container">
		<div class="row">
			<div class="col-lg-3"></div>
			<div class="col-lg-6">
				<div class="jumbotron">
					<!---<h3 class="text-center font-weight-bold">Menu</h3>-->
					<br>
					<div class="row">
						<ul class="nav nav-pills " id="pills-tab" role="tablist">
							<li class="nav-item col-4" role="presentation">
								<a class="nav-item active btn btn-info btn-md"  id="pills-accept-tab" data-toggle="pill"  href="#pills-accept" role="tab" aria-controls="pills-accept" aria-selected="true"><i class="fa fa-book"></i>Accept</a>
							</li>
							<li class="nav-item col-4" role="presentation">
								<a class="nav-link btn btn-info btn-md" id="pills-submit-tab" data-toggle="pill"  href="#pills-submit" role="tab" aria-controls="pills-submit" aria-selected="false"><i class="fa fa-bookmark"></i>Submited</a>
							</li>
							<li class="nav-item col-4" role="presentation">
								<a class="nav-link btn btn-info btn-md" id="pills-unsubmit-tab" data-toggle="pill"  href="#pills-unsubmit" role="tab" aria-controls="pills-unsubmit" aria-selected="false"><i class="fa fa-book"></i>UnSubmited</a>
							</li>
						</ul>
					</div>
				</div>	
			</div>
			<div class="col-lg-3"></div>
		</div>
		<br>
		<div class="row">
			<div class="col-lg-12">
				<div class="jumbotron">
					
					<div class="tab-content" id="pills-tabContent">
						<div class="tab-pane fade show active" id="pills-accept" role="tabpanel" aria-labelledby="pills-accept-tab">
							<!--<h3 class="text-center text-info font-weight-bold">Accepted</h3>--->
							<br>
							<div class="row">
								<div class="col-12">
									<ul class="nav nav-pills " id="pills-tab" role="tablist">
										<li class="nav-item col-4" role="presentation">
											<a class="nav-item active btn btn-info btn-md"  id="pills-accepted-tab" data-toggle="pill"  href="#pills-accepted" role="tab" aria-controls="pills-accepted" aria-selected="true"><i class="fa fa-book"></i>Accept</a>
										</li>
										<li class="nav-item col-4" role="presentation">
											<a class="nav-link btn btn-primary btn-md" id="pills-reject-tab" data-toggle="pill"  href="#pills-reject" role="tab" aria-controls="pills-reject" aria-selected="false"><i class="fa fa-bookmark"></i>Reject</a>
										</li>
										<li class="nav-item col-4" role="presentation">
											<a class="nav-link btn btn-danger btn-md" id="pills-delete-tab" data-toggle="pill"  href="#pills-delete" role="tab" aria-controls="pills-delete" aria-selected="false"><i class="fa fa-book"></i>Delete</a>
										</li>
									</ul>
								</div>
							</div>
							<div class="row">
								<div class="col-12">
									<div class="tab-content" id="pills-tabContent">
										<div class="tab-pane fade show active" id="pills-accepted" role="tabpanel" aria-labelledby="pills-accepted-tab">
											<br>
											<h3 class="text-center text-primary font-weight-bold">Acceptance</h3>
											<br>
											<div class="table-responsive table-md">
												<table class="table table-margin">
													<thead class="bg-success">
														<tr>
															<th class="font-weight-bold">Regno</th>
															<th class="font-weight-bold">Name</th>
															<th class="font-weight-bold">BookName</th>
															<th class="font-weight-bold">RefNo</th>
															<th class="font-weight-bold">Select</th>
														</tr>
													</thead>
													<tbody>
														<?php
															$sql = "SELECT * FROM `stud_order` WHERE `status`='accepted' And `sub_status` IS NULL";
															$res = $con->query($sql);
															if ($res == true) {
																//echo "query true";
																if ($res->num_rows>0) {
																	while ($row = $res->fetch_assoc()) {
																		echo "<tr>";
																		echo "<td>{$row['regno']}</td>";
																		echo "<td>{$row['name']}</td>";
																		echo "<td>{$row['b_name']}</td>";
																		echo "<td>{$row['refno']}</td>";
																		echo "<td><button type='button' class='btn btn-md btn-info accept' data-id='{$row['refno']}' data_id='{$row['regno']}'><i class='fa fa-address-card'></i></button></td>";
																		echo "</tr>";
																	}
																}
															}
															else{
																echo "query failed";
															}
														?>
													</tbody>
												</table>
											</div>
										</div>
										<div class="tab-pane fade" id="pills-reject" role="tabpanel" aria-labelledby="pills-reject-tab">
											<br>
											<h3 class="text-center text-success font-weight-bold">Reject</h3>
											<br>
											<div class="table-responsive table-md">
												<table class="table-margin table">
													<thead class="bg-white text-black">
														<tr>
															<th class="font-weight-bold">Regno</th>
															<th class="font-weight-bold">Order_Date</th>
															<th class="font-weight-bold">BookName</th>
															<th class="font-weight-bold">Select</th>
															<!--<th class="font-weight-bold"></th>-->
														</tr>
													</thead>
													<tbody>
														<?php

															$sql1 = "SELECT * FROM `stud_order` WHERE `status`='Rejected' AND `sub_status` IS NULL";
															$out = $con->query($sql1);
															if ($out == true) {
																//echo "query true";
																if ($out->num_rows>0) {
																	while ($data = $out->fetch_assoc()) {
																		echo "<tr>";
																		echo "<td>{$data['regno']}</td>";
																		echo "<td>{$data['order_date']}</td>";
																		echo "<td>{$data['b_name']}</td>";
																		echo "<td><button class='btn btn-sm btn-danger delete' data-id='{$data['refno']}' data_id='{$data['regno']}'><i class='fa fa-trash'></i></button></td>";
																		echo "<td><button class='btn btn-primary btn-sm reaccept' data_id='{$data['regno']}' data-id='{$data['refno']}'><i class='fa fa-send'></i></button></td>";
																		echo "<td><button class='btn btn-primary btn-sm view_reject' data_reg='{$data['regno']}' data_ref='{$data['refno']}'><i class='fa fa-id-card'></i></button></td>";
																		echo "</tr>";
																	}
																}
															}
															else{
																echo "query failed";
															}


														?>
													</tbody>
												</table>
											</div>
										</div>
										<div class="tab-pane fade" id="pills-delete" role="tabpanel" aria-labelledby="pills-delete-tab">
											<br>
											<h3 class="text-center text-secondary font-weight-bold">Delete</h3>
											<br>
											<div class="table-responsive table-md">
												<table class="table table-margin">
													<thead class="bg-danger">
														<tr>
															<th class="font-weight-bold">Regno</th>
															<th class="font-weight-bold">order_date</th>
															<th class="font-weight-bold">Deuo_date</th>
															<th class="font-weight-bold">Sub_status</th>
															<th class="font-weight-bold">Delete</th>
														</tr>
													</thead>
													<tbody>
														<?php

															$sql2 = "SELECT * FROM `stud_order` WHERE `sub_status`='submited'";
															$output = $con->query($sql2);
															if ($output == true) {
																//echo "Query True";
																if ($output ->num_rows>0) {
																	while ($data1 = $output->fetch_assoc()) {
																		echo "<tr>";
																		echo "<td>{$data1['regno']}</td>";
																		echo "<td>{$data1['order_date']}</td>";
																		echo "<td>{$data1['deuo_date']}</td>";
																		echo "<td>{$data1['sub_status']}</td>";
																		echo "<td><button class='btn btn-md btn-danger del' data_id='{$data1['regno']}' data-id='{$data1['refno']}'><i class='fa fa-trash'></i></button></td>";
																		echo "</tr>";
																	}
																}
															}
															else{
																echo "Query Failed";
															}

														?>
													</tbody>
												</table>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="tab-pane fade" id="pills-submit" role="tabpanel" aria-labelledby="pills-submit-tab">
							<br>
							<h3 class="text-center text-info font-weight-bold">Submit</h3>
							<br>
							<div class="table-responsive table-md">
								<table class="table table-margin">
									<thead>
										<tr>
											<th>Regno</th>
											<th>BookName</th>
											<th>DeliveryDate</th>
											<th>DeuoDate</th>
											<th>Sub_Date</th>
											<th>Sub_status</th>
										</tr>
									</thead>
									<tbody>
										<?php

											$sql3 = "SELECT * FROM `stud_order` WHERE `sub_status`='submited'";
											$out1 = $con->query($sql3);
											if ($out1 == true) {
												//echo "query true";
												if ($out1->num_rows>0) {
													while ($data2 = $out1->fetch_assoc()) {
														echo "<tr>";
														echo "<td>{$data2['regno']}</td>";
														echo "<td>{$data2['b_name']}</td>";
														echo "<td>{$data2['del_date']}</td>";
														echo "<td>{$data2['deuo_date']}</td>";
														echo "<td>{$data2['sub_date']}</td>";
														echo "<td>{$data2['sub_status']}</td>";
														echo "</tr>";
													}
												}
											}
											else{
												echo "query failed";
											}


										?>
									</tbody>
								</table>
							</div>
						</div>
						<div class="tab-pane fade" id="pills-unsubmit" role="tabpanel" aria-labelledby="pills-unsubmit-tab">
							<br>
							<h3 class="text-center text-info font-weight-bold">UnSubmit</h3>
							<br>
							<div class="table-responsive table-md">
								<table class="table table-margin">
									<thead>
										<tr>
											<th>Regno</th>
											<th>BookName</th>
											<th>DeliveryDate</th>
											<th>DeuoDate</th>
											<th></th>
											<th>Select</th>
										</tr>
									</thead>
									<tbody>
										<?php

											$sql3 = "SELECT * FROM `stud_order` WHERE `sub_status`='unsubmited'";
											$out1 = $con->query($sql3);
											if ($out1 == true) {
												//echo "query true";
												if ($out1->num_rows>0) {
													while ($data2 = $out1->fetch_assoc()) {
														echo "<tr>";
														echo "<td>{$data2['regno']}</td>";
														echo "<td>{$data2['b_name']}</td>";
														echo "<td>{$data2['del_date']}</td>";
														echo "<td>{$data2['deuo_date']}</td>";
														echo "<td><button class='btn btn-md btn-success view' data-id='{$data2['refno']}' data_reg='{$data2['regno']}'><i class='fa fa-id-card'></i></button></td>";
														echo "<td><button class='btn btn-md btn-info update' data-ref='{$data2['refno']}' data-reg='{$data2['regno']}'><i class='fa fa-send'></i></button></td>";
														echo "</tr>";
													}
												}
											}
											else{
												echo "query failed";
											}


										?>
									</tbody>
								</table>
							</div>
						</div>

					</div>
				</div>
			</div>
		</div>		
	</div>
	<!--------container end--------->
<!---footer------>
	<footer class="page-footer font-small blue-grey lighten-5 animated delay-2s bounceInUp">
		<div style="background-color: #21d192;">
    		<div class="container">
      			<div class="row py-4 d-flex align-items-center">
        			<div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
          				<h6 class="mb-1 font-weight-bold">Get connected with us on social networks!</h6>
        			</div>
        			<div class="col-md-6 col-lg-7 text-center text-md-right">
          				<a class="fb-ic">
            				<i class="fa fa-facebook-f fa-2x white-text mr-4"> </i>
          				</a>
          				<a class="tw-ic">
            				<i class="fa fa-twitter fa-2x white-text mr-4"> </i>
          				</a>
          			    <a class="gplus-ic">
            				<i class="fa fa-google-plus fa-2x white-text mr-4"> </i>
          				</a>
          			    <a class="li-ic">
            				<i class="fa fa-linkedin fa-2x white-text mr-4"> </i>
          				</a>
          				<a class="ins-ic">
            				<i class="fa fa-instagram fa-2x white-text"> </i>
          				</a>
        			</div>
        		</div>
      		</div>
  		</div>
  		<div class="container text-center text-md-left mt-5">
    	   	<div class="row mt-3 dark-grey-text">
      	    	<div class="col-md-3 col-lg-4 col-xl-3 mb-4">
               		<h6 class="text-uppercase font-weight-bold">Company name</h6>
        			<hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        			<p>Here you can use rows and columns to organize your footer content. Lorem ipsum dolor sit amet,
          				consectetur
          				adipisicing elit.</p>
      			</div>
      			<div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
        	    	<h6 class="text-uppercase font-weight-bold">Products</h6>
        			<hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        			<p>
          				<a class="dark-grey-text" href="#!">MDBootstrap</a>
        			</p>
        			<p>
          				<a class="dark-grey-text" href="#!">PHP,JQUERY</a>
        			</p>
        			<p>
          				<a class="dark-grey-text" href="#!">AJAX,JAVASCRIPT</a>
        			</p>
        			<p>
          				<a class="dark-grey-text" href="#!">HTML,CSS</a>
        			</p>
      			</div>
      		  	<div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
        	    	<h6 class="text-uppercase font-weight-bold">Useful links</h6>
        			<hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        			<p>
          				<a class="dark-grey-text" href="#!">Student Login</a>
        			</p>
        			<p>
          				<a class="dark-grey-text" href="#!">LibraryAdmin</a>
        			</p>
        			<p>
          				<a class="dark-grey-text" href="#!">Head Of Department</a>
        			</p>
        			<p>
          				<a class="dark-grey-text" href="#!">Representative Login</a>
        			</p>
      			</div>
      		   	<div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
        	    	<h6 class="text-uppercase font-weight-bold">Contact</h6>
        			<hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        			<p>
          				<i class="fa fa-home mr-3"></i> 79/a mettu street,  Thirupparankundream,  Madurai,  India</p>
        			<p>
          				<i class="fa fa-envelope mr-3"></i> naveenkumar709434@gmail.com</p>
        			<p>
          				<i class="fa fa-phone mr-3"></i> + 63 796 179 16</p>
        			<p>
          				<i class="fa fa-print mr-3"></i> + 99 42 93 32 62</p>
      			</div>
      		</div>
    	</div>
  	 	<div class="footer-copyright text-center text-black-50 py-3">© 2020 Copyright:
    		<a class="dark-grey-text" href="https://mdbootstrap.com/">StrategySoftwares.com</a>
  		</div>
  	</footer>
	<!---footer end---->

<!-- jQuery -->
  	<script type="text/javascript" src="../js/jquery.min.js"></script>
  	<!-- Bootstrap tooltips -->
  	<script type="text/javascript" src="../js/popper.min.js"></script>
  	<!-- Bootstrap core JavaScript -->
  	<script type="text/javascript" src="../js/bootstrap.min.js"></script>
  	<!-- MDB core JavaScript -->
  	<script type="text/javascript" src="../js/mdb.min.js"></script>
  	<!-- Your custom scripts (optional) -->
    
  	<script type="text/javascript">
  		//finish
  		$(document).on('click','.accept',function(){
  			var regno = $(this).attr('data_id');
  			var refno = $(this).attr('data-id');
  			//alert(regno);
  			//alert(refno);
  			window.location.href="accept_update.php?regno="+regno+"&&refno="+refno;
  		});
  		$(document).on('click','.delete',function(){
  			var regno = $(this).attr('data_id');
  			var refno = $(this).attr('data-id');
  			//var nk="reject_delete";
  			//alert(regno);
  			//alert(refno);
  			$.ajax({
  				url : "reject_delete.php",
  				method : "POST",
  				data : {regno:regno,refno:refno},
  				success:function(data){
  					alert(data);
  					window.location.href="lib_work.php";
  				}
  			});
  		});
  		$(document).on('click','.reaccept',function(){
  			var reg = $(this).attr('data_id');
  			var ref = $(this).attr('data-id');
  			//alert(reg);
  			//alert(ref);
  			$.ajax({
  				url : "reaccept_work.php",
  				method : "POST",
  				data : {reg:reg,ref:ref},
  				success:function(data){
  					alert(data);
  					window.location.href="lib_work.php";
  				}
  			});
  		});
  		$(document).on('click','.del',function(){
  			var regno = $(this).attr('data_id');
  			var refno = $(this).attr('data-id');
  			//var nk="";
  			//alert(reg);
  			//alert(ref);
  			$.ajax({
  				url : "delete_data.php",
  				method : "POST",
  				data : {regno:regno,refno:refno},
  				success:function(data){
  					alert(data);
  					window.location.href="lib_work.php";
  				}
  			});

  		});
  		//finish
  		$(document).on('click','.view',function(){
  			var refno = $(this).attr('data-id');
  			var regno = $(this).attr('data_reg');
  			//alert(refno);
  			//alert(regno);
  			window.location.href="unsubmit_view.php?regno="+regno+"&&refno="+refno;
  		});
  		$(document).on('click','.update',function(){
  			var regno = $(this).attr('data-reg');
  			var refno = $(this).attr('data-ref');
  			//alert(regno);
  			//alert(refno);
  			$.ajax({
  				url : "reaccept.php",
  				method : "POST",
  				data : {regno:regno,refno:refno},
  				success:function(data){
  					alert(data);
  					window.location.href="lib_work.php";
  				}
  			});
  		});
  		$(document).on('click','.view_reject',function
  			(){
  				var regno = $(this).attr('data_reg');
  				var refno = $(this).attr('data_ref');
  				//alert(regno);
  				//alert(refno);
  				window.location.href="reject_view.php?regno="+regno+"&&refno="+refno;
  			});
  	</script>
</body>
</html>