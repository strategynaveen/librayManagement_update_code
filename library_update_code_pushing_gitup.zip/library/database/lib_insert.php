<?php

include("db_config.php");
if ($con->connect_error) {
	die('connection failed'.$con->connect_error);
}
else{
	//echo "connection successfully";
	if ((empty($_POST["lib_name"])) && (empty($_POST["lib_email"])) && (empty($_POST["lib_phone"])) && (empty($_POST["lib_gender"])) && (empty($_POST["lib_add"])) && (empty($_POST["lib_dob"])) && (empty($_POST["lib_uid"])) && (empty($_POST["lib_pass"])) && (empty($_POST["lib_repass"]))) {
		echo "please fill the entire fields";
	}
	elseif (empty($_POST["lib_name"])) {
		echo "please fill the name";
	}
	elseif (empty($_POST["lib_email"])) {
		echo "please fill the email";
	}
	elseif (empty($_POST["lib_phone"])) {
		echo "please fill the phone number";
	}
	elseif (empty($_POST["lib_gender"])) {
		echo "please fill the gender";
	}
	elseif (empty($_POST["lib_add"])) {
		echo "please fill the address";
	}
	elseif (empty($_POST["lib_dob"])) {
		echo "please fill the date of birth";
	}
	elseif (empty($_POST["lib_uid"])) {
		echo "please fill the username";
	}
	elseif (empty($_POST["lib_pass"])) {
		echo "please fill the password";
	}
	elseif (empty($_POST["lib_repass"])) {
		echo "please fill the retype password";
	}
	elseif (strcmp($_POST["lib_pass"], $_POST["lib_repass"]) !=0) {
		echo "incorrect password and retype password";
	}
	else{

		$uid=$_POST["lib_uid"];
		$name=$_POST["lib_name"];
		$email=$_POST["lib_email"];
		$mobile=$_POST["lib_phone"];
		$gender=$_POST["lib_gender"];
		$add=$_POST["lib_add"];
		$dob=$_POST["lib_dob"];
		$pass=$_POST["lib_pass"];

		$sql="SELECT `userid`, `name`, `email`, `mobile`, `gender`, `address`, `dob`, `password` FROM `lib_incharge` WHERE `userid`='".$uid."' ";

		$res=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($res);
		$count=mysqli_num_rows($res);
		if ($count==1) {
			echo "already using this userid";
			echo "<br>";
		}
		else{
			echo "new userid ";
			echo "<br>";
			$query="INSERT INTO `lib_incharge`(`userid`, `name`, `email`, `mobile`, `gender`, `address`, `dob`, `password`) VALUES ('".$uid."','".$name."','".$email."','".$mobile."','".$gender."','".$add."','".$dob."','".$pass."')";
			if ($con->query($query)==true) {
				echo "Record Inserted SucccessFully";
				header('location: lib_incharge.html');
			}
			else{
				echo "error";
			}
		}
	}
}



?>