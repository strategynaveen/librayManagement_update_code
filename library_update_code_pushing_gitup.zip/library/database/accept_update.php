<?php

//print_r($_GET);

$regno=$_GET["regno"];
$refno=$_GET["refno"];

include('db_config.php');
if ($con->connect_error) {
	die('connection failed'.$con->connect_error);
}
else{
	//echo "connection successfully";
}



?>
<!DOCTYPE html>
<html>
<head>
	<title>DeliveryBook</title>
	<!-- MDB icon -->
  <link rel="icon" href="../img/mdb-favicon.ico" type="image/x-icon">
  <!-- Font Awesome --
  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.11.2/css/all.css">
  <-- Google Fonts Roboto --
  <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700&display=swap">
  <-- Bootstrap core CSS -->
  <link rel="stylesheet" href="../css/bootstrap.min.css">
  <!-- Material Design Bootstrap -->
  <link rel="stylesheet" href="../css/mdb.min.css">
  <!-- Your custom styles (optional) -->
  <link rel="stylesheet" href="../css/style.css">
  <link rel="stylesheet" href="../fa/css/font-awesome.min.css">
 <!---<link rel="stylesheet" type="text/css" href="main.css">---->
 <link rel="stylesheet" type="text/css" href="../style.css">
</head>
<body>
	<!----navigation----->
	<!--navigation----->
	<div class="cont-col-nav animated bounceInRight slow">
		<h4 class="text-center ">Library Management</h4>
	</div>
	<!--Navbar -->
	<nav class=" mb-0 navbar sticky-top navbar-expand-lg navbar-dark col-nav animated bounceInRight slow" id="myHeader">
  		<a class="navbar-brand" href="#">Navbar</a>
  		<button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent-333" aria-controls="navbarSupportedContent-333" aria-expanded="false" aria-label="Toggle navigation">
    		<span class="navbar-toggler-icon"></span>
  		</button>
  		<div class="collapse navbar-collapse" id="navbarSupportedContent-333">
    		<ul class="navbar-nav mr-auto">
      			<li class="nav-item active">
        			<a class="nav-link" href="../index.html">Home
          				<span class="sr-only">(current)</span>
        			</a>
      			</li>
      			<li class="nav-item">
        			<a class="nav-link" href="../stud_login.html">Student</a>
      			</li>
      			<li class="nav-item dropdown">
              <a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-444" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">Incharge</a>
              <div class="dropdown-menu dropdown-default" aria-labelledby="navbarDropdownMenuLink-444">
                <a class="dropdown-item" href="../lib_incharge.html">Login</a>
                <a class="dropdown-item" href="../book_view.html">SearchBook</a>
                <a class="dropdown-item" href="../b_reg.html">ADDBook</a>
                <a class="dropdown-item" href="lib_work.php">Work</a>
                <a class="dropdown-item" href="order_view.php">Orders</a>
              </div>
            </li>
      			<li class="nav-item dropdown">
        			<a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-333" data-toggle="dropdown"
          			aria-haspopup="true" aria-expanded="false">HOD</a>
        			<div class="dropdown-menu dropdown-default" aria-labelledby="navbarDropdownMenuLink-333">
          				<a class="dropdown-item" href="../hod_register.html">Register</a>
          				<a class="dropdown-item" href="../hod_login.html">Login</a>
          				<a class="dropdown-item" href="hod_unsubmit.php">Unsubmit</a>
        			</div>
      			</li>
    		</ul>
    		<ul class="navbar-nav ml-auto nav-flex-icons">
      			<li class="nav-item">
        			<a class="nav-link waves-effect waves-light">
          				<i class="fa fa-twitter"></i>
        			</a>
      			</li>
      			<li class="nav-item">
        			<a class="nav-link waves-effect waves-light">
          				<i class="fa fa-google-plus"></i>
        			</a>
      			</li>
      			<li class="nav-item dropdown">
        			<a class="nav-link dropdown-toggle" id="navbarDropdownMenuLink-333" data-toggle="dropdown"
          			aria-haspopup="true" aria-expanded="false">
          				<i class="fa fa-user "></i>
        			</a>
        			<div class="dropdown-menu dropdown-menu-right dropdown-default" aria-labelledby="navbarDropdownMenuLink-333">
          				<a class="dropdown-item" href="#">Action</a>
          				<a class="dropdown-item" href="#">Another action</a>
          				<a class="dropdown-item" href="#">Something else here</a>
        			</div>
      			</li>
    		</ul>
 		</div>
	</nav>
	<br>
	<!-----navigation end ------->
	<!--------container--------->
	<div class="container">
		<div class="row">
			<div class="col-lg-3"></div>
			<div class="col-lg-6">
				<div class="jumbotron">
					<h3 class="text-center text-info font-weight-bold">Book Submission</h3>
					<br>
					<form method="POST" id="myform">
					<?php

						$sql ="SELECT * FROM `stud_order` WHERE `regno`='$regno' AND `refno`='$refno'";
						$res = $con->query($sql);
						if ($res == true) {
							//echo "query true";
							if ($res->num_rows>0) {
								while ($row = $res->fetch_assoc()) {
									?>
									<div class="md-form">
  										<i class="fa fa-id-card prefix"></i>
  										<input type="number" id="regno" name="regno" class="form-control form-control-md" value="<?php echo $row['regno']; ?>" required="true" readonly>
  										<label for="regno">RegisterNumber</label>
									</div>
									<div class="md-form">
  										<i class="fa fa-user prefix"></i>
  										<input type="text" id="name" name="name" class="form-control form-control-md" value="<?php echo $row['name']; ?>" required="true" readonly>
  										<label for="name">Name</label>
									</div>
									<div class="md-form">
  										<i class="fa fa-building prefix"></i>
  										<input type="text" id="dept" name="dept" class="form-control form-control-md" value="<?php echo $row['dept']; ?>" required="true" readonly>
  										<label for="dept">Department</label>
									</div>
									<div class="md-form">
  										<i class="fa fa-id-card prefix"></i>
  										<input type="text" id="c_year" name="c_year" class="form-control form-control-md" value="<?php echo $row['current_year']; ?>" required="true" readonly>
  										<label for="c_year">CurrentYear</label>
									</div>
									<div class="md-form">
  										<i class="fa fa-info prefix"></i>
  										<input type="text" id="gender" name="gender" class="form-control form-control-md" value="<?php echo $row['gender']; ?>" required="true" readonly>
  										<label for="gender">Gender</label>
									</div>
									<div class="md-form">
  										<i class="fa fa-book prefix"></i>
  										<input type="text" id="bname" name="bname" class="form-control form-control-md" value="<?php echo $row['b_name']; ?>" required="true" readonly>
  										<label for="bname">BookName</label>
									</div>
									<div class="md-form">
  										<i class="fa fa-id-card prefix"></i>
  										<input type="number" id="refno" name="refno" class="form-control form-control-md" value="<?php echo $row['refno']; ?>" required="true" readonly>
  										<label for="refno">ReferenceNumber</label>
									</div>
									<div class="md-form">
  										<i class="fa fa-book prefix"></i>
  										<input type="number" id="bcount" name="bcount" class="form-control form-control-md" value="<?php echo $row['b_count']; ?>" required="true" readonly>
  										<label for="bcount">Counting</label>
									</div>
									<label>DeliveryDate:</label>
            			<div class="form-group">
              			<div class="InputWithIcon">
                			<input type="date" name="del_date" id="del_date" class="form-control form-control-lg" required="true">
                			<i class="fa fa-calendar"></i>
              			</div>
            			</div>
            			<br>
            			<label>DeuoDate:</label>
            			<div class="form-group">
              		 	<div class="InputWithIcon">
                			<input type="date" name="deuo_date" id="deuo_date" class="form-control form-control-lg" required="true">
                			<i class="fa fa-calendar"></i>
              			</div>
            			</div>
            			<div class="md-form">
  								 	<i class="fa fa-bookmark prefix"></i>
  								  <input type="text" id="sub_status" name="sub_status" class="form-control form-control-md" value="unsubmited" required="true">
  								  <label for="sub_status">SubStatus</label>
									</div>
									<div class="row">
										<div class="col-6">
											<button class="btn btn-lg btn-success back">Back</button>
										</div>
										<div class="col-6">
											<input type="submit" class="btn btn-lg btn-info submit" name="submit"  value="Update">
										</div>
									</div>
									<?php
								}
							}
						}
						else{
							echo "query failed";
						}

					?>
				</form>
				</div>
			</div>
			<div class="col-lg-3"></div>
		</div>
	</div>
	<!---------container end------->
	<!---footer------>
	<footer class="page-footer font-small blue-grey lighten-5 animated delay-2s bounceInUp">
		<div style="background-color: #21d192;">
    		<div class="container">
      			<div class="row py-4 d-flex align-items-center">
        			<div class="col-md-6 col-lg-5 text-center text-md-left mb-4 mb-md-0">
          				<h6 class="mb-1 font-weight-bold">Get connected with us on social networks!</h6>
        			</div>
        			<div class="col-md-6 col-lg-7 text-center text-md-right">
          				<a class="fb-ic">
            				<i class="fa fa-facebook-f fa-2x white-text mr-4"> </i>
          				</a>
          				<a class="tw-ic">
            				<i class="fa fa-twitter fa-2x white-text mr-4"> </i>
          				</a>
          			    <a class="gplus-ic">
            				<i class="fa fa-google-plus fa-2x white-text mr-4"> </i>
          				</a>
          			    <a class="li-ic">
            				<i class="fa fa-linkedin fa-2x white-text mr-4"> </i>
          				</a>
          				<a class="ins-ic">
            				<i class="fa fa-instagram fa-2x white-text"> </i>
          				</a>
        			</div>
        		</div>
      		</div>
  		</div>
  		<div class="container text-center text-md-left mt-5">
    	   	<div class="row mt-3 dark-grey-text">
      	    	<div class="col-md-3 col-lg-4 col-xl-3 mb-4">
               		<h6 class="text-uppercase font-weight-bold">Company name</h6>
        			<hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        			<p>Here you can use rows and columns to organize your footer content. Lorem ipsum dolor sit amet,
          				consectetur
          				adipisicing elit.</p>
      			</div>
      			<div class="col-md-2 col-lg-2 col-xl-2 mx-auto mb-4">
        	    	<h6 class="text-uppercase font-weight-bold">Products</h6>
        			<hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        			<p>
          				<a class="dark-grey-text" href="#!">MDBootstrap</a>
        			</p>
        			<p>
          				<a class="dark-grey-text" href="#!">PHP,JQUERY</a>
        			</p>
        			<p>
          				<a class="dark-grey-text" href="#!">AJAX,JAVASCRIPT</a>
        			</p>
        			<p>
          				<a class="dark-grey-text" href="#!">HTML,CSS</a>
        			</p>
      			</div>
      		  	<div class="col-md-3 col-lg-2 col-xl-2 mx-auto mb-4">
        	    	<h6 class="text-uppercase font-weight-bold">Useful links</h6>
        			<hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        			<p>
          				<a class="dark-grey-text" href="#!">Student Login</a>
        			</p>
        			<p>
          				<a class="dark-grey-text" href="#!">LibraryAdmin</a>
        			</p>
        			<p>
          				<a class="dark-grey-text" href="#!">Head Of Department</a>
        			</p>
        			<p>
          				<a class="dark-grey-text" href="#!">Representative Login</a>
        			</p>
      			</div>
      		   	<div class="col-md-4 col-lg-3 col-xl-3 mx-auto mb-md-0 mb-4">
        	    	<h6 class="text-uppercase font-weight-bold">Contact</h6>
        			<hr class="teal accent-3 mb-4 mt-0 d-inline-block mx-auto" style="width: 60px;">
        			<p>
          				<i class="fa fa-home mr-3"></i> 79/a mettu street,  Thirupparankundream,  Madurai,  India</p>
        			<p>
          				<i class="fa fa-envelope mr-3"></i> naveenkumar709434@gmail.com</p>
        			<p>
          				<i class="fa fa-phone mr-3"></i> + 63 796 179 16</p>
        			<p>
          				<i class="fa fa-print mr-3"></i> + 99 42 93 32 62</p>
      			</div>
      		</div>
    	</div>
  	 	<div class="footer-copyright text-center text-black-50 py-3">© 2020 Copyright:
    		<a class="dark-grey-text" href="https://mdbootstrap.com/">StrategySoftwares.com</a>
  		</div>
  	</footer>
	<!---footer end---->

<!-- jQuery -->
  	<script type="text/javascript" src="../js/jquery.min.js"></script>
  	<!-- Bootstrap tooltips -->
  	<script type="text/javascript" src="../js/popper.min.js"></script>
  	<!-- Bootstrap core JavaScript -->
  	<script type="text/javascript" src="../js/bootstrap.min.js"></script>
  	<!-- MDB core JavaScript -->
  	<script type="text/javascript" src="../js/mdb.min.js"></script>
  	<!-- Your custom scripts (optional) -->
    
  	<script type="text/javascript">
  		$(document).on('click','.back',function(){
  			alert('im the best');
  			window.location.href="lib_work.php";
  		});
  		$(document).on('click','.submit',function(){
  			//alert('hi guys');
  			
  			$.ajax({
  				url : "accept.php",
          method : "POST",
          data : $('#myform').serialize(),
          success:function(data){
            alert(data);
            //window.location.href="lib_work.php";
          }
  			});
  		});
  	</script>
</body>
</html>