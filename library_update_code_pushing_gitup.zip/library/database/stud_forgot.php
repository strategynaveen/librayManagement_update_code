<?php

	//print_r($_POST);

include("db_config.php");
if ($con->connect_error) {
	die('connection failed'.$con->connect_error);
}
else{
	echo "connection successfully";
	if ((empty($_POST["stud_reg"])) && (empty($_POST["stud_dept"])) && (empty($_POST["stud_phone"])) && (empty($_POST["stud_dob"])) && (empty($_POST["stud_pass"])) && (empty($_POST["stud_repass"]))) {
		echo "please enter the entire field";
	}
	elseif (empty($_POST["stud_reg"])) {
		echo "please enter the student register number ";
	}
	elseif (empty($_POST["stud_dept"])) {
		echo "please enter the student department";
	}
	elseif (empty($_POST["stud_phone"])) {
		echo "please enter the student phone number";
	}
	elseif (empty($_POST["stud_dob"])) {
		echo "please enter the student date of birth";
	}
	elseif (empty($_POST["stud_pass"])) {
		echo "please enter the student password";
	}
	elseif (empty($_POST["stud_repass"])) {
		echo "please enter the student  retype password";
	}
	elseif (strcmp($_POST["stud_pass"], $_POST["stud_repass"]) !=0) {
		echo "Password And Retype Password Are Not Equals";
	}
	else{
		$regno=$_POST["stud_reg"];
		$dept=$_POST["stud_dept"];
		$mobile=$_POST["stud_phone"];
		$dob=$_POST["stud_dob"];
		$pass=$_POST["stud_pass"];
		$sql="SELECT * FROM `student` WHERE `regno`='".$regno."' and `dept`='".$dept."' ";
		$res=mysqli_query($con,$sql);
		$row=mysqli_fetch_array($res);
		$count=mysqli_num_rows($res);

		if ($count==1) {
			echo "first step is verified";
			echo "<br>";
			
			$query="SELECT `regno`, `name`, `dept`, `mobile`, `gmail`, `gender`, `address`, `dob`, `current_year`, `pass` FROM `student` WHERE `mobile`=$mobile and `regno`=$regno ";
			$result=mysqli_query($con,$query);
			$row1=mysqli_fetch_array($result);
			$count_1=mysqli_num_rows($result);

			if ($count_1==1) {
				echo "second step is verified";
				$sql2="UPDATE `student` SET `pass`='".$pass."' WHERE `regno`='".$regno."' ";
				if ($con->query($sql2)==true) {
					echo "password updated successfully";
					header('location: ../stud_login.html');
				}
				else{
					echo "password not updated some errors".$con."";
				}
			}
			else{
				echo "wrong mobile number in the correct register number";
			}
		}
		else{
			echo "wrong register number and department";
		}
	}
}



?>